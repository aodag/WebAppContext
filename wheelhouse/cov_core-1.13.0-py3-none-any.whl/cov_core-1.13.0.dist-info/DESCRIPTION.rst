cov-core
========

This is a lib package for use by pytest-cov, nose-cov and nose2-cov.  Unless you're developing a
coverage plugin for a test framework, you probably want one of those.

